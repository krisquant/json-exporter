# JSON Exporter
A Java library for converting objects to JSON using annotations.

## Features
- Annotation-based JSON serialization
- Support for nested objects and collections
- Custom field naming
- File export capabilities
