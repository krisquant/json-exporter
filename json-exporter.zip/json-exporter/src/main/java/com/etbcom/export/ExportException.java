package com.etbcom.export;

public class ExportException extends RuntimeException {
    public ExportException(String message) {
        super(message);
    }
}